A Pen created at CodePen.io. You can find this one at https://codepen.io/hexagoncircle/pen/KXEKyE.

 So gooey. So loader. <a href="https://css-tricks.com/gooey-effect/">Inspiration here</a>.